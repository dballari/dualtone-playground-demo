/* Block search replace tool scripts
------------------------------------ */
function setSearch(value) {
    document.getElementById("search_text").value = value;
}
function setAction(value) {
    document.getElementById("action").value = value;
}
