<?php

/**
 * DualTone WordPress theme scripts
 *
 * @package	DualTone Theme Data
 * @author	David Ballarin Prunera
 * @license	GNU General Public License v2
 * @link	https://ballarinconsulting.com/dualtone
 */

$scripts = [
    [
        'src' => '/assets/js/scripts.js',
        'deps' => []
    ]
];
