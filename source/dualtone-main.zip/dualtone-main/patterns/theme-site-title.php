<?php
/**
 * Title: Title
 * Slug: dualtone/theme-site-title
 * Inserter: no
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:site-tagline {"style":{"typography":{"fontStyle":"italic","fontWeight":"var(--wp--custom--font-weight--default)"}},"fontSize":"large"} /--></div>
<!-- /wp:group -->
