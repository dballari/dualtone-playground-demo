<?php
/**
 * Title: Page content
 * Slug: dualtone/theme-page-content
 * Inserter: no
 */
?>
<!-- wp:group {"tagName":"main","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<main class="wp-block-group" style="margin-bottom:var(--wp--preset--spacing--40)"><!-- wp:post-title {"level":1} /-->

<!-- wp:post-content /--></main>
<!-- /wp:group -->
