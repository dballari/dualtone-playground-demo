<?php
/**
 * Title: Bar
 * Slug: dualtone/utilities-bar
 * Categories: utilities
 */
?>
<!-- wp:separator {"style":{"spacing":{"margin":{"top":"0px","bottom":"0px"}}},"className":"is-style-default"} -->
<hr class="wp-block-separator has-alpha-channel-opacity is-style-default" style="margin-top:0px;margin-bottom:0px"/>
<!-- /wp:separator -->
