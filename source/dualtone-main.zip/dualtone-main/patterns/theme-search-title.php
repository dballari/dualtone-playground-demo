<?php
/**
 * Title: Search title
 * Slug: dualtone/theme-search-title
 * Inserter: no
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:query-title {"type":"search"} /--></div>
<!-- /wp:group -->
