<?php
/**
 * Title: After post content
 * Slug: dualtone/theme-after-post-content
 * Inserter: no
 */
?>
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"left"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:post-terms {"term":"category","separator":"·","prefix":"Categories: "} /-->

<!-- wp:post-terms {"term":"post_tag","separator":"·","prefix":"Tags: "} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"left"}} -->
<div class="wp-block-group is-style-vborder"><!-- wp:post-navigation-link {"type":"previous","label":"","showTitle":true,"style":{"layout":{"selfStretch":"fixed","flexSize":"100%"}}} /-->


<!-- wp:post-navigation-link {"textAlign":"right","label":"","showTitle":true,"style":{"layout":{"selfStretch":"fixed","flexSize":"100%"}}} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
