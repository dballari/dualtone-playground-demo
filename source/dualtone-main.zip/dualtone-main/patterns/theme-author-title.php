<?php
/**
 * Title: Author title
 * Slug: dualtone/theme-author-title
 * Inserter: no
 */
?>
<!-- wp:group {"layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:query-title {"type":"archive","showPrefix":false} /-->

<!-- wp:post-author-biography /--></div>
<!-- /wp:group -->
