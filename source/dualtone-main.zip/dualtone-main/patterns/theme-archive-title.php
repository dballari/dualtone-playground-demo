<?php
/**
 * Title: Archive title
 * Slug: dualtone/theme-archive-title
 * Inserter: no
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:query-title {"type":"archive","showPrefix":false} /-->

<!-- wp:term-description /--></div>
<!-- /wp:group -->
